import { Loaders } from "./core/loader";
import { client } from "./core/client";
import { ENV } from "./config/env";
import { shutdown } from "./core/shutdown";
import { logger } from "./utils/logger";

if (!ENV.clientId || !ENV.token) {
  logger.error("Client ID or Token not found");
  (async () => await shutdown())();
  process.exit(1);
}

(async () => {
  try {
    const loaders = new Loaders();

    await loaders.LoadAll();
    await loaders.RegisterCommands();

    await client.login(ENV.token);
    logger.info("Client logged in as: " + client.user?.username);
  } catch (err) {
    logger.error("Bot initialization error: " + err);
  }
})();

process.on("SIGINT", async () => {
  logger.info("SIGINT");
  await shutdown();
});

process.on("SIGTERM", async () => {
  logger.info("SIGTERM");
  await shutdown();
});
