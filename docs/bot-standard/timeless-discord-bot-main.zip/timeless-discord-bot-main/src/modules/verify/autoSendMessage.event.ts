import { ChannelType, Events } from "discord.js";
import { Event } from "../../types/interactions";
import { client } from "../../core/client";
import { createMessage } from "../../utils/responceCreate";

export default {
  name: Events.ClientReady,
  /**
   * Replaces the previous bot messages in the verification channel with the
   * current verification instructions.
   *
   * @throws When the verification channel is missing or is not a text channel.
   */
  async execute(..._args) {
    const channel = await client.channels.fetch("1572013749395529910").catch(() => {
      throw new Error(
        "Verification channel not found. Check the configured channel ID and the bot's access.",
      );
    });

    if (!channel || channel.type !== ChannelType.GuildText) {
      throw new Error(
        "Verification channel is not a text channel. Update the configured channel ID.",
      );
    }

    const messages = await channel.messages.fetch();
    const botMessages = messages.filter((msg) => msg.author.id === client.user!.id);
    await Promise.all(botMessages.map((msg) => msg.delete()));

    await channel.send(
      createMessage({
        embedData: {
          title: "✅ Verify your account",
          description: [
            "Welcome to **Timeless**! Verification keeps our community safe and unlocks the rest of the server.",
            "",
            "**How to verify**",
            "1. Open your direct messages from **Timeless** — we sent you one when you joined.",
            "2. Click the green **Verify** button in that message.",
            "3. Your roles update automatically and you are ready to explore the server.",
            "",
            "Already verified? You can safely ignore this message.",
          ].join("\n"),
        },
      }),
    );
  },
} satisfies Event;
