import { PermissionFlagsBits, SlashCommandBuilder } from "discord.js";
import { Command } from "../../types/interactions";
import { verifyUser } from "./verify";

export default {
  data: new SlashCommandBuilder()
    .setName("verify")
    .setDescription("Verify a member and give them access to the server")
    .setDefaultMemberPermissions(
      PermissionFlagsBits.Administrator || PermissionFlagsBits.ManageRoles,
    )
    .addUserOption((o) =>
      o.setName("user").setDescription("The member to verify").setRequired(true),
    ),
  /**
   * Verifies the member selected with the `/verify` command.
   *
   * @param interaction - Slash command interaction carrying the target member.
   */
  async execute(interaction) {
    await verifyUser(interaction.options.getUser("user", true).id);

    await interaction.reply({ content: "✅ Member verified successfully.", flags: 64 });
  },
} satisfies Command;
