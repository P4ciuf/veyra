import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { Button } from "../../types/interactions";
import { verifyUser } from "./verify";

export default {
  customId: "verify_button",
  /**
   * Verifies the member who pressed the button, confirms the result privately
   * and disables the button to prevent duplicate attempts.
   *
   * @param interaction - Button interaction that triggered verification.
   */
  async execute(interaction) {
    const user = interaction.user;

    await verifyUser(user.id);

    await interaction.followUp({
      content:
        "✅ You're verified! Welcome to **Timeless**. Use the button below to head to the server.",
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setLabel("Go to Timeless")
            .setStyle(ButtonStyle.Link)
            .setURL("https://discord.com/channels/1485672833559298060/1485673912380428492"),
        ),
      ],
      flags: 64,
    });

    await interaction.update({
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setCustomId("verify_button")
            .setLabel("Verified")
            .setStyle(ButtonStyle.Success)
            .setEmoji("✅")
            .setDisabled(true),
        ),
      ],
    });
  },
} satisfies Button;
