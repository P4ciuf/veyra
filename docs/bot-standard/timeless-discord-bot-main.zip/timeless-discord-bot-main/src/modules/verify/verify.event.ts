import { ActionRowBuilder, ButtonBuilder, ButtonStyle, Events, GuildMember } from "discord.js";
import { Event } from "../../types/interactions";
import { createMessage } from "../../utils/responceCreate";

export default {
  name: Events.GuildMemberAdd,
  /**
   * Assigns the pending-verification role and sends the verification prompt
   * to the new member's direct messages.
   *
   * @param args - The joining `GuildMember` passed by Discord.
   */
  async execute(...args) {
    const user = args[0] as GuildMember;
    const dmChannel = user.dmChannel ?? (await user.createDM());

    await user.roles.add("1572015078830505987");
    await dmChannel.send(
      createMessage({
        content: `<@${user.id}>`,
        embedData: {
          title: "✅ Verify your account",
          description:
            "Welcome to **Timeless**!\n\nClick the **Verify** button below to unlock the rest of the server. It only takes a second.",
          color: 0x57f287,
        },
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId(`verify_button`)
              .setLabel("Verify")
              .setStyle(ButtonStyle.Success)
              .setEmoji("✅"),
          ),
        ],
      }),
    );
  },
} satisfies Event;
