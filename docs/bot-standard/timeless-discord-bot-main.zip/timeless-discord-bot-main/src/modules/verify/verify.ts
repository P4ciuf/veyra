import { GuildMember } from "discord.js";
import { client } from "../../core/client";

/**
 * Grants the verified role to a member and removes the pending-verification role.
 *
 * @param userId - Discord ID of the member to verify.
 * @throws When the member cannot be fetched from the configured guild.
 */
export async function verifyUser(userId: string) {
  const guild = client.guilds.cache.get("1485672833559298060");
  const member = (await guild?.members.fetch(userId).catch(() => {
    throw new Error(
      `Member ${userId} could not be found in the server. Make sure they are still a member.`,
    );
  })) as GuildMember;
  const memberRoles = member.roles;

  await memberRoles.add("1485748460169986138");
  await memberRoles.remove("1572015078830505987");
}
