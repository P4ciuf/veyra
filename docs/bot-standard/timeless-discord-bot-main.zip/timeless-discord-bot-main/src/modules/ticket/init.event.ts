import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, Events } from "discord.js";
import { Event } from "../../types/interactions";
import { client } from "../../core/client";
import { createMessage } from "../../utils/responceCreate";

export default {
  name: Events.ClientReady,
  async execute(..._args) {
    const channel = await client.channels.fetch("1485895352916901959").catch(() => {
      throw new Error(
        "Ticket panel channel could not be found. Check the configured channel ID and the bot's access.",
      );
    });

    if (!channel || channel.type !== ChannelType.GuildText) {
      throw new Error(
        "Ticket panel channel is not a text channel. Update the configured channel ID.",
      );
    }

    const messages = await channel.messages.fetch();
    const botMessages = messages.filter((msg) => msg.author.id === client.user!.id);
    await Promise.all(botMessages.map((msg) => msg.delete()));

    await channel.send(
      createMessage({
        embedData: {
          title: "🎫 Timeless Ticket Center",
          description: [
            "Welcome to the **Timeless** ticket center. Choose an option below to open a dedicated ticket channel for your request.",
            "",
            "**How it works**",
            "1. Choose the option that best matches your request: **Team Tryout**, **Support**, or **Other**.",
            "2. A new channel named `ticket-<your username>` is created in the ticket category.",
            "3. You'll be mentioned in the new channel. Describe your request there.",
            "4. When you're finished, press the **Close Ticket** button in that channel.",
            "",
            "**Good to know**",
            "• You can have only one open ticket at a time.",
            "• Closing a ticket permanently deletes the channel and its messages.",
          ].join("\n"),
          color: 0x5865f2,
        },
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId("open_ticket_1")
              .setLabel("Team Tryout")
              .setEmoji("🎯")
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId("open_ticket_2")
              .setLabel("Support")
              .setEmoji("🛠️")
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId("open_ticket_3")
              .setLabel("Other")
              .setEmoji("💬")
              .setStyle(ButtonStyle.Primary),
          ),
        ],
      }),
    );
  },
} satisfies Event;
