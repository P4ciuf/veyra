import { ButtonStyle, ChannelType } from "discord.js";
import { Button } from "../../types/interactions";
import { createMessage, createResponseWithEmbed } from "../../utils/responceCreate";
import { ActionRowBuilder, ButtonBuilder } from "@discordjs/builders";

export default {
  customId: (id) => id.startsWith("open_ticket"),
  async execute(interaction) {
    if (!interaction.guild) return;
    const member = interaction.member;
    const ticketCategory = await interaction.client.channels
      .fetch("1485895941327163443")
      .catch(() => {
        throw new Error(
          "Ticket category could not be found. Check the configured category ID and the bot's access.",
        );
      });

    if (!ticketCategory || !(ticketCategory.type == ChannelType.GuildCategory)) {
      throw new Error(
        "The configured ticket channel is not a category. Update the configured category ID.",
      );
    }

    const channels = Array.from((await interaction.guild.channels.fetch()).values()).filter(
      (channel) => channel?.parentId === "1485895941327163443",
    );

    let ticketExitst: boolean = false;
    channels.forEach((c) =>
      c?.name.includes(member?.user.username as string) ? (ticketExitst = true) : void 0,
    );

    if (ticketExitst) {
      await interaction.reply(
        createResponseWithEmbed(
          {
            title: "❌ Ticket Already Open",
            description: [
              "You already have an open ticket.",
              "",
              "You can have only one open ticket at a time. Please continue in your existing ticket channel, or close it before opening a new one.",
            ].join("\n"),
            color: 0xff0000,
          },
          true,
        ),
      );
      return;
    }

    const ticket = await interaction.client.guilds.cache.first()?.channels.create({
      name: `ticket-${member?.user.username}`,
      parent: ticketCategory.id,
    });

    await ticket?.send(
      createMessage({
        content: `<@${member?.user.id}>`,
        embedData: {
          title: "🎫 Ticket Opened",
          description: [
            "Welcome! This channel was created for your request.",
            "",
            "Please describe what you need below. When you're finished, press the **Close Ticket** button to delete this channel.",
          ].join("\n"),
          color: 0x5865f2,
        },
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId("close_ticket")
              .setLabel("Close Ticket")
              .setEmoji({ name: "🔒" })
              .setStyle(ButtonStyle.Danger),
          ),
        ],
      }),
    );

    interaction.reply(
      createResponseWithEmbed(
        {
          title: "✅ Ticket Created",
          description:
            "Your ticket channel has been created in the ticket category. Please continue the conversation there.",
          color: 0x57f287,
        },
        true,
      ),
    );
  },
} satisfies Button;
