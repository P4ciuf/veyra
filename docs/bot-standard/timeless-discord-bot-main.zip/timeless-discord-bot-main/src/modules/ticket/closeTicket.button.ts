import { Button } from "../../types/interactions";

export default {
  customId: "close_ticket",
  async execute(interaction) {
    if (!interaction.guild) return;
    await interaction.channel?.delete();
  },
} satisfies Button;
