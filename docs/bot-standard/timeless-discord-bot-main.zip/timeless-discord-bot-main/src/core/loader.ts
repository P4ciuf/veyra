import path from "path";
import fs from "fs";
import { pathToFileURL } from "url";
import { REST, Routes } from "discord.js";
import { client } from "./client";
import { ENV } from "../config/env";
import { logger } from "../utils/logger";
import { Button, Command } from "../types/interactions";

/** Categorie di interazione gestite dal loader. */
type Kind = "buttons" | "commands" | "events" | "menus" | "modals";

/** Callback di registrazione: riceve il path del file, ritorna 1 se registrato, 0 altrimenti. */
type ModuleHandler = (filePath: string) => Promise<number>;

/**
 * Carica automaticamente i moduli di interazione e li registra sul client Discord.
 *
 * Sorgenti scansionate (ricorsivamente, solo file `.ts` / `.js`):
 *
 * 1. Cartelle "classiche", dove la categoria è data dalla cartella:
 *    - `src/commands`
 *    - `src/events`
 *    - `src/handlers/buttons`
 *    - `src/handlers/menus`
 *    - `src/handlers/modals`
 *
 * 2. Cartella `src/modules`, dove la categoria è dedotta per ogni file:
 *    - dal suffisso nel nome: `ticket.events.ts`, `open.commands.ts`, `close.buttons.ts`
 *    - oppure dalla cartella antenata più vicina con nome di categoria:
 *      `modules/ticket/commands/open.ts`, `modules/ticket/events/ready.ts`
 *    Il suffisso ha la precedenza sulla cartella. Singolare e plurale sono
 *    equivalenti (`.event.ts` = `.events.ts`).
 *
 * I file `.d.ts`, `.test.*` e `.spec.*` vengono ignorati. I moduli con forma
 * non valida vengono loggati e saltati: non bloccano mai il loader.
 */
export class Loaders {
  /** Ordine fisso di caricamento delle categorie. */
  private static readonly KINDS: readonly Kind[] = [
    "buttons",
    "commands",
    "events",
    "menus",
    "modals",
  ];

  /** Nomi (singolari e plurali) riconosciuti per ogni categoria, in minuscolo. */
  private static readonly ALIASES: Record<Kind, readonly string[]> = {
    buttons: ["button", "buttons"],
    commands: ["command", "commands"],
    events: ["event", "events"],
    menus: ["menu", "menus"],
    modals: ["modal", "modals"],
  };

  /** Esclusi dalla scansione: dichiarazioni di tipo e file di test. */
  private static readonly IGNORED_FILE = /\.d\.ts$|\.(test|spec)\.(ts|js)$/i;

  /** Estensioni considerate moduli. */
  private static readonly MODULE_FILE = /\.(ts|js)$/i;

  /** Handler di registrazione per categoria. */
  private readonly handlers: Record<Kind, ModuleHandler> = {
    buttons: (p) => this.loadButton(p),
    commands: (p) => this.loadCommand(p),
    events: (p) => this.loadEvent(p),
    menus: (p) => this.loadMenu(p),
    modals: (p) => this.loadModal(p),
  };

  /** Moduli registrati con successo per categoria (azzerato a ogni `LoadAll`). */
  private loadCounts: Record<Kind, number> = this.emptyCounts();

  /** Listener degli eventi registrati da questo loader, per poterli rimuovere al reload. */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private eventListeners: { name: string; listener: (...args: any[]) => unknown }[] = [];

  /**
   * Carica tutte le categorie nell'ordine fisso e logga i totali.
   * Può essere richiamato a caldo: prima di ricaricare rimuove tutto ciò che
   * aveva registrato (vedi {@link unloadAll}).
   * Directory mancanti producono solo un warning, quindi un bot parzialmente
   * configurato si avvia comunque.
   */
  public async LoadAll(): Promise<void> {
    this.unloadAll();
    this.loadCounts = this.emptyCounts();

    for (const kind of Loaders.KINDS) {
      await this.load(kind);
    }

    const c = this.loadCounts;
    logger.info(
      `✓ Total loaded: ${c.buttons} buttons, ${c.commands} commands, ${c.events} events, ${c.menus} menus, ${c.modals} modals`,
    );
  }

  /**
   * Registra su Discord (comandi globali dell'applicazione) tutti i comandi
   * caricati da `LoadAll`, ovvero quelli di `src/commands` e di `src/modules`.
   * Va chiamato dopo `LoadAll`. Un errore dell'API viene loggato e non lanciato,
   * così il bot può comunque fare il login.
   */
  public async RegisterCommands(): Promise<void> {
    if (!ENV.token || !ENV.clientId) {
      logger.error("Cannot register commands: missing token or client ID");
      return;
    }

    const body = [...client.commands.values()].map((cmd) => cmd.data.toJSON());

    try {
      logger.info(`Started refreshing ${body.length} application (/) commands.`);

      const rest = new REST().setToken(ENV.token);
      const data = await rest.put(Routes.applicationCommands(ENV.clientId), { body });

      logger.info(
        `Successfully reloaded ${(data as { length: number }).length} application (/) commands.`,
      );
    } catch (error) {
      logger.error("Error while reloading application (/) commands: ", error);
    }
  }

  /**
   * Svuota tutto ciò che il loader ha registrato in precedenza, così che un
   * nuovo `LoadAll` parta da zero per ogni categoria: rimuove i listener degli
   * eventi e azzera i registri di bottoni, comandi, menu e modal. In questo modo
   * un file cancellato o rinominato sparisce davvero e nulla viene duplicato.
   * Al primo avvio non c'è nulla da rimuovere.
   */
  private unloadAll(): void {
    for (const { name, listener } of this.eventListeners) {
      client.removeListener(name, listener);
    }
    this.eventListeners = [];

    client.buttons.clear();
    client.commands.clear();
    client.menus.clear();
    client.modals.clear();
  }

  // ---------------------------------------------------------------------------
  // Scansione
  // ---------------------------------------------------------------------------

  /**
   * Carica una categoria da tutte le sue sorgenti: prima le cartelle classiche,
   * poi `src/modules`. Un file raggiunto da più sorgenti viene caricato una sola volta.
   */
  private async load(kind: Kind): Promise<void> {
    const handler = this.handlers[kind];
    const seen = new Set<string>();

    const register = async (file: string): Promise<void> => {
      const key = path.resolve(file);
      if (seen.has(key)) return;
      seen.add(key);
      this.loadCounts[kind] += await handler(file);
    };

    // 1) Cartelle classiche: la categoria è data dalla cartella.
    for (const dir of this.getLegacyPaths(kind)) {
      if (!fs.existsSync(dir)) {
        logger.warn(`Path does not exist: ${dir}`);
        continue;
      }

      for (const file of this.walk(dir)) {
        await register(file);
      }
    }

    // 2) Modules: la categoria è dedotta dal suffisso o dalla cartella.
    const modulesRoot = this.getModulesRoot();
    if (fs.existsSync(modulesRoot)) {
      for (const file of this.walk(modulesRoot)) {
        if (this.detectKind(file) === kind) {
          await register(file);
        }
      }
    }
  }

  /**
   * Cartelle classiche di una categoria. Ancorate alla directory di questo
   * file, quindi valide sia da sorgente (tsx) sia da output compilato (`dist/`).
   */
  private getLegacyPaths(kind: Kind): string[] {
    const base = path.join(__dirname, "..");

    const map: Record<Kind, string[]> = {
      buttons: [path.join(base, "handlers", "buttons")],
      commands: [path.join(base, "commands")],
      events: [path.join(base, "events")],
      menus: [path.join(base, "handlers", "menus")],
      modals: [path.join(base, "handlers", "modals")],
    };

    return map[kind];
  }

  /** Cartella radice dei moduli "a feature". */
  private getModulesRoot(): string {
    return path.join(__dirname, "..", "modules");
  }

  /**
   * Raccoglie ricorsivamente i file modulo di una directory.
   * L'ordine è alfabetico, così il caricamento è deterministico.
   */
  private walk(dir: string): string[] {
    const files: string[] = [];

    const items = fs
      .readdirSync(dir, { withFileTypes: true })
      .sort((a, b) => a.name.localeCompare(b.name));

    for (const item of items) {
      const p = path.join(dir, item.name);

      if (item.isDirectory()) {
        files.push(...this.walk(p));
      } else if (Loaders.MODULE_FILE.test(item.name) && !Loaders.IGNORED_FILE.test(item.name)) {
        files.push(p);
      }
    }

    return files;
  }

  /**
   * Deduce la categoria di un file dentro `src/modules`.
   * Priorità: 1) suffisso nel nome (`foo.events.ts`),
   *           2) cartella antenata più vicina con nome di categoria.
   *
   * @returns La categoria, oppure `null` se il file non appartiene a nessuna.
   */
  private detectKind(filePath: string): Kind | null {
    const rel = path.relative(this.getModulesRoot(), filePath);
    const segments = rel.split(path.sep);
    const fileName = segments.pop() as string;

    const parts = fileName.replace(Loaders.MODULE_FILE, "").toLowerCase().split(".");
    if (parts.length > 1) {
      const fromSuffix = this.kindFromAlias(parts[parts.length - 1]!);
      if (fromSuffix) return fromSuffix;
    }

    for (let i = segments.length - 1; i >= 0; i--) {
      const fromDir = this.kindFromAlias(segments[i]!.toLowerCase());
      if (fromDir) return fromDir;
    }

    return null;
  }

  /** Converte un nome (`event`, `events`, ...) nella categoria corrispondente. */
  private kindFromAlias(name: string): Kind | null {
    for (const kind of Loaders.KINDS) {
      if (Loaders.ALIASES[kind].includes(name)) return kind;
    }
    return null;
  }

  private emptyCounts(): Record<Kind, number> {
    return { buttons: 0, commands: 0, events: 0, menus: 0, modals: 0 };
  }

  // ---------------------------------------------------------------------------
  // Import
  // ---------------------------------------------------------------------------

  /**
   * Importa dinamicamente un file e ne estrae l'export utile: `default`
   * (anche doppiamente annidato in caso di interop CJS/ESM), oppure un export
   * con nome (`command`, `event`, `button`, `modal`, `menu`).
   *
   * Il risultato resta non tipizzato perché ogni loader ne valida la forma.
   * La query `?update=` aggira la cache dei moduli, quindi un file modificato
   * viene reimportato alla successiva `LoadAll` senza riavviare il processo.
   *
   * @throws Rilancia l'errore di import dopo averlo loggato.
   */
  // I moduli sono scritti dall'utente e diventano tipizzati solo dopo la validazione.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private async importModule(filePath: string): Promise<any> {
    const url = `${pathToFileURL(path.resolve(filePath)).href}?update=${Date.now()}`;

    try {
      const imported = await import(url);

      if (imported.default !== undefined) {
        if (typeof imported.default === "object" && imported.default.default !== undefined) {
          return imported.default.default;
        }
        return imported.default;
      }

      return (
        imported.command ??
        imported.event ??
        imported.button ??
        imported.modal ??
        imported.menu ??
        imported
      );
    } catch (error) {
      logger.error(`Failed to import module from ${filePath}:`, error);
      throw error;
    }
  }

  // ---------------------------------------------------------------------------
  // Registrazione per categoria
  // Ogni loader ritorna 1 se il modulo è stato registrato, 0 se saltato o fallito.
  // Non lanciano mai eccezioni.
  // ---------------------------------------------------------------------------

  /** Registra un bottone sotto il suo `customId`. */
  private async loadButton(p: string): Promise<number> {
    try {
      const btn = await this.importModule(p);

      if (!btn || !btn.customId || typeof btn.execute !== "function") {
        logger.warn(`Button not loaded from ${p}: missing customId or execute function`);
        return 0;
      }

      client.buttons.set(btn.customId, btn as Button);
      return 1;
    } catch (err) {
      logger.error(`Error loading button from ${p}:`, err);
      return 0;
    }
  }

  /** Registra uno slash command sotto `data.name`. Richiede `data` ed `execute`. */
  private async loadCommand(p: string): Promise<number> {
    try {
      const cmd = await this.importModule(p);

      if (!cmd || !cmd.data || typeof cmd.execute !== "function") {
        logger.warn(`Command not loaded from ${p}: missing data or execute function`);
        return 0;
      }

      client.commands.set(cmd.data.name, cmd as Command);
      return 1;
    } catch (err) {
      logger.error(`Error loading command from ${p}:`, err);
      return 0;
    }
  }

  /**
   * Collega `execute` di un evento al client. Con `once: true` usa `client.once`,
   * altrimenti `client.on`; gli argomenti vengono inoltrati invariati.
   */
  private async loadEvent(p: string): Promise<number> {
    try {
      const evt = await this.importModule(p);

      if (!evt || !evt.name || typeof evt.execute !== "function") {
        logger.warn(`Event not loaded from ${p}: missing ${!evt?.name ? "name" : "execute"}`);
        return 0;
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const listener = (...args: any[]) => evt.execute(...args);

      if (evt.once) {
        client.once(evt.name, listener);
      } else {
        client.on(evt.name, listener);
      }

      this.eventListeners.push({ name: evt.name, listener });
      return 1;
    } catch (err) {
      logger.error(`Error loading event from ${p}:`, err);
      return 0;
    }
  }

  /**
   * Registra un select menu. Se `customId` è una funzione, la chiave è il nome
   * della funzione (o `"dynamic"` se anonima).
   */
  private async loadMenu(p: string): Promise<number> {
    try {
      const menu = await this.importModule(p);

      if (!menu || !menu.customId || typeof menu.execute !== "function") {
        logger.warn(
          `Menu not loaded from ${p}: missing ${!menu?.customId ? "customId" : "execute"}`,
        );
        return 0;
      }

      const key =
        typeof menu.customId === "function" ? menu.customId.name || "dynamic" : menu.customId;

      client.menus.set(key, menu);
      return 1;
    } catch (err) {
      logger.error(`Error loading menu from ${p}:`, err);
      return 0;
    }
  }

  /**
   * Registra un modal. Se `customId` è una funzione, la chiave è il suo
   * codice sorgente (`toString()`), deterministico per modulo.
   */
  private async loadModal(p: string): Promise<number> {
    try {
      const modal = await this.importModule(p);

      if (!modal || !modal.customId || typeof modal.execute !== "function") {
        logger.warn(
          `Modal not loaded from ${p}: missing ${!modal?.customId ? "customId" : "execute"}`,
        );
        return 0;
      }

      const key = typeof modal.customId === "function" ? modal.customId.toString() : modal.customId;

      client.modals.set(key, modal);
      return 1;
    } catch (err) {
      logger.error(`Error loading modal from ${p}:`, err);
      return 0;
    }
  }
}
