import { logger } from "../utils/logger";
import { client } from "./client";

/**
 * Gracefully disconnects the shared Discord client.
 *
 * Called by `main.ts` when the process exits (missing env, SIGINT/SIGTERM) and
 * internally as the boot error path.
 *
 * @async
 * @returns Resolves once the client is destroyed. Never rejects: a destroy
 * failure is logged through the shared logger instead of being rethrown.
 */
export async function shutdown() {
  try {
    await client.destroy();
    logger.info("Client successfully destroyed");
  } catch (err) {
    logger.error("Bot shutdown error: " + err);
  }
}
