import dotenv from "dotenv";

dotenv.config({ path: [".env", ".env.local"] });

export const ENV = {
  token: process.env.TOKEN,
  clientId: process.env.CLIENT_ID,
  nodeEnv: process.env.NODE_ENV,
};
