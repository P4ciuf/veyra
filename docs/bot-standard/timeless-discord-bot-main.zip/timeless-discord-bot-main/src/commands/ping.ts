import { SlashCommandBuilder } from "discord.js";
import ms from "ms";
import { Command } from "../types/interactions";
import { createResponseWithEmbed } from "../utils/responceCreate";

export default {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Show the bot's latency and uptime"),
  /**
   * Replies with the current gateway latency and process uptime.
   *
   * @param interaction - Slash command interaction that triggered the reply.
   */
  async execute(interaction) {
    interaction.reply(
      await createResponseWithEmbed(
        {
          title: "🏓 Pong!",
          description: `**Latency:** ${interaction.client.ws.ping}ms\n**Uptime:** ${ms(interaction.client.uptime)}`,
          color: 0x5865f2,
        },
        true,
      ),
    );
  },
} satisfies Command;
