import {
  ButtonInteraction,
  ChatInputCommandInteraction,
  ModalSubmitInteraction,
  SlashCommandBuilder,
  SlashCommandOptionsOnlyBuilder,
  SlashCommandSubcommandsOnlyBuilder,
  StringSelectMenuInteraction,
} from "discord.js";

export interface Command {
  data: SlashCommandBuilder | SlashCommandOptionsOnlyBuilder | SlashCommandSubcommandsOnlyBuilder;
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

export interface Button {
  customId: string | ((id: string) => boolean);
  execute: (interaction: ButtonInteraction) => Promise<void>;
}

export interface Event {
  name: string;
  once?: boolean;
  execute: (...args: unknown[]) => Promise<void> | void;
}

export interface Menu {
  customId: string;
  execute: (interaction: StringSelectMenuInteraction) => Promise<void>;
}

export type Modal = {
  customId: string | ((id: string) => boolean);
  execute: (interaction: ModalSubmitInteraction) => void;
};
