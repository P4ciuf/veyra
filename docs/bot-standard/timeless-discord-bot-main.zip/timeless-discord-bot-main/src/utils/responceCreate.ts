import {
  APIEmbed,
  EmbedBuilder,
  InteractionReplyOptions,
  MessageCreateOptions,
  MessageFlags,
} from "discord.js";
import { client } from "../core/client";

function createEmbed(data: Partial<APIEmbed>): EmbedBuilder {
  const embed = new EmbedBuilder().setFooter({
    text: "Timeless • Made by P4ciuf",
    iconURL: client.user?.displayAvatarURL({ extension: "webp" }),
  });

  if (data.author) embed.setAuthor(data.author);
  if (data.color) embed.setColor(data.color);
  if (data.description) embed.setDescription(data.description);
  if (data.footer) embed.setFooter(data.footer);
  if (data.image) embed.setImage(data.image.url);
  if (data.thumbnail) embed.setThumbnail(data.thumbnail.url);
  if (data.timestamp) embed.setTimestamp();
  if (data.title) embed.setTitle(data.title);

  return embed;
}

export function createResponseWithEmbed(
  data: Partial<APIEmbed>,
  ephemeral: boolean = false,
): InteractionReplyOptions {
  const response: InteractionReplyOptions = { embeds: [createEmbed(data)] };
  if (ephemeral) response.flags = MessageFlags.Ephemeral;
  return response;
}

type CreateMessageProps = {
  content?: string;
  embedData?: APIEmbed;
  components?: MessageCreateOptions["components"];
};

export function createMessage(props: CreateMessageProps): MessageCreateOptions {
  const { content, embedData, components } = props;
  if (!content && !embedData) throw new Error("content or embed data are required");

  const message: MessageCreateOptions = {};

  if (content) message.content = content;
  if (embedData) message.embeds = [createEmbed(embedData)];
  if (components) message.components = components;

  return message;
}

/**
 * Builds a user-facing error embed.
 *
 * @param err - Short, user-safe description of the problem. Never pass raw exceptions or stack traces.
 * @returns An embed with a clear title, explanation and retry hint.
 */
export function createErrorEmbed(
  err: string = "We couldn't complete that request. Please try again in a moment.",
): EmbedBuilder {
  return new EmbedBuilder({
    title: "❌ Something went wrong",
    description: err,
    color: 0xff0000,
    footer: {
      text: "Please try again.",
      icon_url: client.user?.displayAvatarURL({ extension: "webp" }),
    },
  });
}
