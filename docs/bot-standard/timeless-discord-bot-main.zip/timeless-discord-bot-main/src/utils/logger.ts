import winston from "winston";
import DailyRotateFile from "winston-daily-rotate-file";
import path from "path";
import fs from "fs";

const logsDir = path.resolve(process.cwd(), "logs");
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

const COLOURS = {
  error: "\x1b[31m",
  warn: "\x1b[33m",
  info: "\x1b[36m",
  debug: "\x1b[35m",
  audit: "\x1b[32m",
  reset: "\x1b[0m",
};

const isDevelopment = process.env.NODE_ENV === "development";

const timestamp = winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" });

// Costruisce la riga di testo comune a console e file
const buildLine = (info: winston.Logform.TransformableInfo): { key: string; text: string } => {
  const { level, message, timestamp, audit, ...meta } = info;
  const label = audit ? "AUDIT" : level.toUpperCase();
  const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
  return {
    key: audit ? "audit" : level,
    text: `[${timestamp}] [${label}] ${message}${metaStr}`,
  };
};

const colouredConsole = winston.format.printf((info) => {
  const { key, text } = buildLine(info);
  const colour = COLOURS[key as keyof typeof COLOURS] ?? "";
  return `${colour}${text}${COLOURS.reset}`;
});

const plainFile = winston.format.printf((info) => buildLine(info).text);

const transports: winston.transport[] = [
  new winston.transports.Console({
    level: isDevelopment ? "debug" : "info",
    format: winston.format.combine(timestamp, colouredConsole),
  }),

  // Unico file: riceve OGNI log (debug, info, warn, error, audit)
  new DailyRotateFile({
    level: "debug",
    datePattern: "YYYY-MM-DD",
    maxFiles: "7d",
    zippedArchive: false,
    filename: path.join(logsDir, "logs-%DATE%.log"),
    format: winston.format.combine(timestamp, plainFile),
  }),
];

const log = winston.createLogger({
  level: "debug", // il filtro per la console è sul transport
  transports,
  exitOnError: false,
});

type Meta = unknown;

// Normalizza qualsiasi cosa passata come meta in un oggetto serializzabile
const normalizeMeta = (meta?: Meta): Record<string, unknown> => {
  if (meta === undefined || meta === null) return {};
  if (meta instanceof Error) {
    return { error: { name: meta.name, message: meta.message, stack: meta.stack } };
  }
  if (typeof meta === "object" && !Array.isArray(meta)) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(meta as Record<string, unknown>)) {
      out[k] = v instanceof Error ? { name: v.name, message: v.message, stack: v.stack } : v;
    }
    return out;
  }
  return { meta };
};

export interface AuditEntry {
  actor: string; // chi ha fatto l'azione (userId, email, "system")
  action: string; // es. "user.login", "order.delete"
  resource?: string; // su cosa (es. "order:123")
  outcome?: "success" | "failure";
  [key: string]: unknown; // dettagli extra
}

export const logger = {
  error(message: string, meta?: Meta): void {
    log.log({ level: "error", message, ...normalizeMeta(meta) });
  },

  warn(message: string, meta?: Meta): void {
    log.log({ level: "warn", message, ...normalizeMeta(meta) });
  },

  info(message: string, meta?: Meta): void {
    log.log({ level: "info", message, ...normalizeMeta(meta) });
  },

  debug(message: string, meta?: Meta): void {
    log.log({ level: "debug", message, ...normalizeMeta(meta) });
  },

  // Audit: finisce nello stesso file, taggato [AUDIT], livello info
  audit(entry: AuditEntry): void {
    const { actor, action, resource, outcome = "success", ...rest } = entry;
    log.log({
      level: "info",
      message: `${actor} ${action}${resource ? ` ${resource}` : ""} -> ${outcome}`,
      audit: true,
      actor,
      action,
      resource,
      outcome,
      ...normalizeMeta(rest),
    });
  },
};
