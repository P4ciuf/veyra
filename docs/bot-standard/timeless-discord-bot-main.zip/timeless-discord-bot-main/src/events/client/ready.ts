import { Events } from "discord.js";
import { Event } from "../../types/interactions";
import { client } from "../../core/client";

export default {
  name: Events.ClientReady,
  once: true,
  async execute() {
    client.user?.setPresence({
      status: "online",
      activities: [
        {
          name: "Made by P4ciuf",
        },
      ],
    });
  },
} satisfies Event;
